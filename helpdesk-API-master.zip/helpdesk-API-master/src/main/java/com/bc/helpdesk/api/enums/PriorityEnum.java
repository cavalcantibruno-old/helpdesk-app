package com.bc.helpdesk.api.enums;

public enum PriorityEnum {
	
	High,
	Normal,
	Low;
	
}
