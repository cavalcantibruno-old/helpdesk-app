package com.bc.helpdesk.api.enums;

public enum ProfileEnum {

	ROLE_ADMIN,
	ROLE_CUSTOMER,
	ROLE_TECHNICIAN
}
