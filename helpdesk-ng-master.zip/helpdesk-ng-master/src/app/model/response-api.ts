export class ResponseApi {
    public data: any;
    public errors: Array<string>;
}